var express=require('express');
var socket=require('socket.io');
fs=require("fs");

//starting server code
var app=express();
var port=process.env.PORT||4000;
var server=app.listen(port,function(){
console.log("Listining to port "+port);
});
//starting server code ends
class Room {
  constructor(room_name,name,socket_id) {
    this.room_name=room_name;
    this.name=name;
    this.id=socket_id;
    this.lock=false;
    this.count=0;
    this.question_index=[];
  }
}
var rooms=[];
var room_player_limit=6;
var timeout_array=[500,1000,2000,3000,3000,3000];
//socket code
var io=socket(server);
io.on('connection',function(socket){

  function send_question(index){

  var obj = JSON.parse(fs.readFileSync('questions.json', 'utf8'));

  var min=0;
  var max=obj.questions.length-1;


if(rooms[index].question_index.length==obj.questions.length)
{
  socket.emit("questions_ended");
  for(var j=0;j<rooms[index].name.length;j++)
  {
    socket.to(rooms[index].id[j]).emit("questions_ended");

  }
  return "null";
}

  var random=rn(min,max);
  while (ls(rooms[index].question_index,random))
  {
    random=rn(min,max);
  }

  rooms[index].question_index.push(random);

  return obj.questions[random];
  }

function rn(min,max){
  return Math.floor(Math.random()*(max-min+1)+min);
}

function ls(arr,key){
for(var i=0;i<arr.length;i++)
{
  if(arr[i]==key)
  {
    return true;
  }
}
return false;
}



//testing connection code
socket.on("test_connection",function(data){
socket.emit("server_working");
});
//testing connection code ends

//create room code
socket.on("create_room",function(data){
var room_name;

var i=0;
for(i=0;i<rooms.length;i++)
{
  if(rooms[i].name.length==0 && rooms[i].lock)
  {
    room_name=i;
    rooms[i].lock=false;
    break;
  }
}
if(i==rooms.length)
{room_name=rooms.length;
}


//do something here
rooms[room_name]=new Room(room_name,[data.name],[socket.id]);
socket.emit("room_created",{query_list:[(room_name).toString(),room_name]});
console.log("new room created,ID:"+room_name+"\ntotal rooms:"+rooms.length);

});
//create room code ends

//join room code
socket.on("join_room",function(data){

  var i=0;
  for( i=0;i<rooms.length;i++)
  {
    if(rooms[i].room_name==data.room_name && !rooms[i].lock && rooms[i].name.length<room_player_limit)
    {  //joined code
        rooms[i].name[rooms[i].name.length]=data.name;
        rooms[i].id[rooms[i].id.length]=socket.id;
        var player=rooms[i];
        socket.emit("join_room_result",{query_list:["successful",i,rooms[i].id.length-1].concat(player.name)});
        console.log("new player joined in room ID:"+rooms[i].room_name+"\n total players in that room:"+rooms[i].name.length);


        for(var j=0;j<player.name.length-1;j++)
        {
          socket.to(player.id[j]).emit("display_players",{query_list:player.name});
        }
        break;
    }
  }

   if(i==rooms.length)
   {  //invalid room
     socket.emit("join_room_result",{query_list:["invalid_room_name"]});
     console.log("invalid room ID:"+data.room_name);
   }

});
//join room code ends

//start game code
socket.on("start_game",function(data){
  rooms[data.room_index].lock=true;
  var ques=send_question(data.room_index);
  socket.emit("start_game_ex",{query_list:[ques]});
  for(var j=1;j<rooms[data.room_index].name.length;j++)
  {
    socket.to(rooms[data.room_index].id[j]).emit("start_game",{query_list:[ques]});
    //send one question here
  }
  console.log("started the game,room ID:"+data.room_index+" players:"+rooms[data.room_index].name.length);

  });
  //start game code ends


socket.on("answer",function(data){

  for(var j=0;j<rooms[data.room_index].name.length;j++)
  {  if(socket.id!=rooms[data.room_index].id[j])
    {socket.to(rooms[data.room_index].id[j]).emit("answer",{query_list:[data.name,data.answer]});

      }
      else{
        rooms[data.room_index].count++;
      }

}
if(rooms[data.room_index].count==rooms[data.room_index].name.length)
{rooms[data.room_index].count=0;
setTimeout(function () {
  var ques=send_question(data.room_index);
  if(ques=="null")
  {
    return;
  }
  socket.emit("question",{query_list:[ques]});
  for(var j=0;j<rooms[data.room_index].name.length;j++)
  {
    socket.to(rooms[data.room_index].id[j]).emit("question",{query_list:[ques]});
    //send one question here
  }
}, timeout_array[rooms[data.room_index].name.length-1]);
}

});




socket.on("message",function(data){
  for(var j=0;j<rooms[data.room_index].name.length;j++)
  {  if(socket.id!=rooms[data.room_index].id[j])
    {socket.to(rooms[data.room_index].id[j]).emit("message",{query_list:[data.name,data.message]});

      }

    }
});



//end game code
socket.on("exit",function(data){
var name=rooms[data.room_index].name[data.player_index];
if(rooms.length==0 ||rooms[data.room_index].name[data.player_index]!=data.name)
{ console.log("invalid player:"+data.name);
  return;
}
rooms[data.room_index].name.splice(data.player_index,1);
rooms[data.room_index].id.splice(data.player_index,1);
if(rooms[data.room_index].name.length==0)
{ rooms[data.room_index].question_index=[];
  rooms[data.room_index].lock=true;
  console.log("room is empty,ID:"+data.room_index);
  return;
}

for(var j=0;j<rooms[data.room_index].name.length;j++)
{
    socket.to(rooms[data.room_index].id[j]).emit("player_index",{query_list:[j.toString(),name,rooms[data.room_index].name.length]});
}
});
//end code game ends

socket.on("forced_exit",function(data){
  var name;
for(var i=0;i<rooms.length;i++)
{
  for(var j=0;j<rooms[i].id.length;j++)
  {
    if(rooms[i].id[i]==socket.id)
    {  name=  rooms[i].name[j];
      rooms[i].name.splice(j,1);
      rooms[i].id.splice(j,1);
      if(rooms[i].name.length==0)
      { rooms[i].question_index=[];
        rooms[i].lock=true;
        console.log("room is empty,ID:"+data.room_index);
        return;
      }

      for(var k=0;k<rooms[i].name.length;k++)
      {
        socket.to(rooms[data.room_inde].id[k]).emit("player_index",{query_list:[k.toString(),name,rooms[i].name.length]});
      }
       break;
    }
  }

}

});

});
//socket code ends
