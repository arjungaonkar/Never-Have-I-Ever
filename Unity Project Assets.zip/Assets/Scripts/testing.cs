﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testing : MonoBehaviour {

	// Use this for initialization
	void Start () {
        StartCoroutine(demo());
	}
	
    IEnumerator demo()
    {
        WWW www = new WWW("https://testingmemegame.000webhostapp.com/url.txt");
        yield return www;
        if(www.error!=null)
        {
            Debug.Log("no internet");
        }
        else
        {
            Debug.Log(www.text);
        }
    }

	// Update is called once per frame
	void Update () {
		
	}
}
