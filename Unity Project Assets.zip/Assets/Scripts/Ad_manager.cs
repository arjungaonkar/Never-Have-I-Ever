﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GoogleMobileAds.Api;
public class Ad_manager : MonoBehaviour {
    public static Ad_manager instance;
    public string andriod_appid= "ca-app-pub-3940256099942544~3347511713";
    public string ios_appid= "ca-app-pub-3940256099942544~1458002511";

    public string andriod_bannerid = "ca-app-pub-3940256099942544/6300978111";
    public string ios_bannerid = "ca-app-pub-3940256099942544/2934735716";

    public BannerView bannerView;
    // Use this for initialization
    void Start () {
		if(instance==null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }

#if UNITY_ANDROID
        string appId =andriod_appid ;
#elif UNITY_IPHONE
            string appId = ios_appid;
#else
            string appId = "unexpected_platform";
#endif

        // Initialize the Google Mobile Ads SDK.
        MobileAds.Initialize(appId);
        
    }

    public void RequestBanner()
    {
#if UNITY_ANDROID
        string adUnitId =andriod_bannerid ;
#elif UNITY_IPHONE
            string adUnitId = ios_bannerid;
#else
            string adUnitId = "unexpected_platform";
#endif

        // Create a 320x50 banner at the top of the screen.
        bannerView = new BannerView(adUnitId, AdSize.SmartBanner, AdPosition.Top);

        // Create an empty ad request.
        AdRequest request = new AdRequest.Builder().Build();

        // Load the banner with the request.
        bannerView.LoadAd(request);
        bannerView.Show();
    }
}
