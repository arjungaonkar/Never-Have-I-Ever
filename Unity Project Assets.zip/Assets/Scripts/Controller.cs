﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using SocketIO;
using System;

[System.Serializable]
class Query
{
    public string[] query_list;
}

public class Controller : MonoBehaviour {
    public SocketIOComponent socket;
    public GameObject main_canvas;
    public GameObject loading_screen;
    public GameObject mainmenu_screen;
    public GameObject FAQ_screen;
    public GameObject room_screen;
    public GameObject display_player_screen;
    public GameObject game_screen;
    public GameObject error_prefab;

    GameObject active_screen;
    bool ishoster=false;
    string player_name;
    string room_index;
    string player_index;
    bool button_click;

    bool exit_click;
    float exit_timer;

    public GameObject message_name;
    public GameObject message_object;
    // Use this for initialization
    void Start () {
        active_screen = loading_screen;
        StartCoroutine(checkInternetConnection());
        
        socket.On("server_working",server_working);
        socket.On("room_created", room_created);
        socket.On("join_room_result", join_room_result);
        socket.On("display_players", display_players);
        socket.On("start_game", start_game);
        socket.On("start_game_ex", start_game_ex);
        socket.On("player_index", player_index_setter);
        socket.On("question", question);
        socket.On("answer", answer);
        socket.On("questions_ended", questions_ended);
        socket.On("message", recieve_message);
    }

    private void Update()
    {


        if (Input.GetKeyDown(KeyCode.Escape))
        {
            exit_click = !exit_click;
           

            if(active_screen==room_screen || active_screen==FAQ_screen)
            {
                active_screen.SetActive(false);
                mainmenu_screen.SetActive(true);
                active_screen = mainmenu_screen;
            }


           else if (active_screen == loading_screen || active_screen == mainmenu_screen)
            {
                Debug.Log("exit");
                Application.Quit();

            }
            else if (exit_timer < 5f && !exit_click)
            {
                  JSONObject j = new JSONObject(JSONObject.Type.OBJECT);
                j.AddField("name", player_name);
                  j.AddField("room_index", room_index);
                 j.AddField("player_index", player_index);
                 socket.Emit("exit", j);
                //go to main menu
                Debug.Log("main menu");
                active_screen.SetActive(false);
                mainmenu_screen.SetActive(true);
                active_screen = mainmenu_screen;
                game_screen.transform.GetChild(4).gameObject.SetActive(false);
                game_screen.transform.GetChild(5).gameObject.SetActive(false);
                try
                {
                    Ad_manager.instance.bannerView.Hide();
                }
                catch
                {

                }
            }
            else
            {
                exit_timer = 0;
               
                error_display("Main menu?", "Press again to go back");
               
            }

        }
        if (exit_click)
        {
            exit_timer += Time.deltaTime;

        }


    }
    



    #region internet and connecting to server
    IEnumerator checkInternetConnection()
    {
        WWW www = new WWW("https://testingmemegame.000webhostapp.com/url.txt");
        yield return www;
        if (www.error != null)
        {
            loading_screen.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text= "Connect to internet!!";
            
            yield return new WaitForSeconds(0.5f);
            StartCoroutine(checkInternetConnection());
        }
        else
        {
           
          //  socket.url = "ws://" +www.text+ "/socket.io/?EIO=4&transport=websocket";
           
            socket.Connect();

            loading_screen.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = "Connecting to server";
           
            InvokeRepeating("test_connect", 0.5f, 0.5f);
        }
    }
    void test_connect()
    {
        socket.Emit("test_connection");
    }

    private void server_working(SocketIOEvent e)
    {
        Debug.Log("working");
        CancelInvoke("test_connect");
        loading_screen.SetActive(false);
        mainmenu_screen.SetActive(true);
        active_screen = mainmenu_screen;
        //nxt phase
    }
    #endregion

    #region main menu
    public void show_room_respective(bool create)
    {
        mainmenu_screen.SetActive(false);
        room_screen.transform.GetChild(1).gameObject.SetActive(create);
        room_screen.transform.GetChild(2).gameObject.SetActive(!create);
        room_screen.transform.GetChild(3).gameObject.SetActive(!create);
        
        room_screen.SetActive(true);
        active_screen = room_screen;
    }
   
    public void show_faq()
    {
        mainmenu_screen.SetActive(false);
        FAQ_screen.SetActive(true);
        active_screen = FAQ_screen;

    }

    public void faq_send(int index)
    {
        TMP_InputField t = FAQ_screen.transform.GetChild(index).GetComponent<TMP_InputField>();
     
        JSONObject j = new JSONObject(JSONObject.Type.OBJECT);
        if(t.text=="")
        {
            return;
        }
        else if (index == 2)
        { j.AddField("suggestion", t.text);
           
        }
        else
        {
            j.AddField("question_suggestion", t.text);
            
        }
        socket.Emit("faq",j);
       
        
    }
    #endregion

    #region creating room 
    public void create_room() {
        player_name = GameObject.FindWithTag("name").GetComponent<TMP_InputField>().text;
        if (player_name == "")
        {
            error_display("Enter name","You need to enter name to play");
            return;
        }
        JSONObject j = new JSONObject(JSONObject.Type.OBJECT);
        j.AddField("name", player_name);
        socket.Emit("create_room",j);
        
    }
    private void room_created(SocketIOEvent e)
    {
        Query q = JsonUtility.FromJson<Query>(e.data.ToString());
        room_index = q.query_list[0];
        player_index = "0";
        Debug.Log("room ID:" + room_index);
        room_screen.SetActive(false);
        display_player_screen.transform.GetChild(2).gameObject.SetActive(true);
        display_player_screen.transform.GetChild(3).gameObject.SetActive(true);
        display_player_screen.transform.GetChild(3).transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = q.query_list[1];
        display_player_screen.SetActive(true);
        active_screen = display_player_screen;
        display_names(player_name);
        ishoster= true;
        
        game_screen.transform.GetChild(5).gameObject.SetActive(false);
        game_screen.transform.GetChild(4).GetChild(1).GetChild(0).GetComponent<TextMeshProUGUI>().text = "0";
    }

    public void share_roomname()
    {
        ShareandRate.instance.OnAndroidTextSharingClick("hey room created,copy and paste it in the app to join","room ID:" +room_index.ToString());
    }
    #endregion

    #region joining room

    public void join_room() {
         player_name = GameObject.FindWithTag("name").GetComponent<TMP_InputField>().text;
        if (player_name == "")
        {
            error_display("Enter name", "You need to enter name to play");
            return;
        }
       string room_name = GameObject.FindWithTag("room_name").GetComponent<TMP_InputField>().text;
        if (room_name == "")
        {
            error_display("Enter room ID","Enter room ID to connect to that room");
            return;
        }
        JSONObject j = new JSONObject(JSONObject.Type.OBJECT);
        j.AddField("name", player_name);
        j.AddField("room_name", room_name);
        socket.Emit("join_room", j);

    }

    void join_room_result(SocketIOEvent e)
    {
        
        Query q = JsonUtility.FromJson<Query>(e.data.ToString());
        
        if(q.query_list[0]=="successful")
        {  
            room_screen.SetActive(false);
            display_player_screen.SetActive(true);
            active_screen = display_player_screen;
            room_index = q.query_list[1];
            player_index= q.query_list[2];
            string n = q.query_list[3];

            for (int i = 4; i < q.query_list.Length; i++)
            {
                n = n + "\n" + q.query_list[i];
            }
            ishoster = false;
            display_player_screen.transform.GetChild(2).gameObject.SetActive(false);
            display_player_screen.transform.GetChild(3).gameObject.SetActive(false);
            display_names(n);

            game_screen.transform.GetChild(4).gameObject.SetActive(true);
            game_screen.transform.GetChild(5).gameObject.SetActive(false);
            game_screen.transform.GetChild(4).GetChild(1).GetChild(0).GetComponent<TextMeshProUGUI>().text = "0";
        }
        else
        {
            error_display("Invalid room ID","Enter correct room ID!");
        }
    }
    #endregion
    #region display
    void display_players(SocketIOEvent e)
    {
        game_screen.transform.GetChild(4).gameObject.SetActive(true);
        game_screen.transform.GetChild(5).gameObject.SetActive(false);
        game_screen.transform.GetChild(4).GetChild(1).GetChild(0).GetComponent<TextMeshProUGUI>().text = "0";
        Query q = JsonUtility.FromJson<Query>(e.data.ToString());
        string n = q.query_list[0];

        for(int i=1;i<q.query_list.Length;i++)
        {
            n = n + "\n" + q.query_list[i];
        }
        display_names(n);
    }

    void display_names(string name) {
        TextMeshProUGUI t = display_player_screen.GetComponentInChildren<TextMeshProUGUI>();
        t.text =name+"\n";
    }
    #endregion
    #region start and end game code
    public void start_game()
    {
        

        JSONObject j = new JSONObject(JSONObject.Type.OBJECT);
        j.AddField("room_index", room_index);
        socket.Emit("start_game",j);
       start_game(new SocketIOEvent(""));
    }
     void start_game(SocketIOEvent e)
    {
        Ad_manager.instance.RequestBanner();
        
       
        GameObject g = game_screen.transform.GetChild(5).gameObject;
        g.SetActive(false);
        g=g.transform.GetChild(0).GetChild(0).gameObject;
        for(int i=0;i<g.transform.childCount;i++)
        {
            Destroy(g.transform.GetChild(i).gameObject);
        }

        display_player_screen.SetActive(false);
        game_screen.SetActive(true);
        active_screen = game_screen;
        if(!ishoster)
        question(e);
    }
    void  start_game_ex(SocketIOEvent e)
    {
        
        question(e);
    }


    private void OnApplicationQuit()
    {
        socket.Emit("forced_exit");
        
    }

    void player_index_setter(SocketIOEvent e)
    {
        Query q = JsonUtility.FromJson<Query>(e.data.ToString());
        player_index = q.query_list[0];
        error_display(q.query_list[1], "Left the game!");
        Debug.Log(q.query_list[2]);
        if(q.query_list[2]=="1")
        {
            game_screen.transform.GetChild(4).gameObject.SetActive(false);
            game_screen.transform.GetChild(5).gameObject.SetActive(false);
        }
    }

    #endregion

    #region game working
    void question(SocketIOEvent e)
    {
        Query q = JsonUtility.FromJson<Query>(e.data.ToString());
        game_screen.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = q.query_list[0];
        button_click = false;
        //set the color back
        game_screen.transform.GetChild(2).GetComponent<UnityEngine.UI.Image>().color = Color.white;
        game_screen.transform.GetChild(3).GetComponent<UnityEngine.UI.Image>().color = Color.white;
        game_screen.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = "";
        //clear answer
        //testing
        /*
        JSONObject j = new JSONObject(JSONObject.Type.OBJECT);
        j.AddField("room_index", room_index);
        j.AddField("name", player_name);
        j.AddField("answer", "Have");
        socket.Emit("answer", j);
        Debug.Log(count++);
        */
        //
    }
    int count = 0;
   public void buttonclick(GameObject b)
    {
       
        if (!button_click)
        {
            JSONObject j = new JSONObject(JSONObject.Type.OBJECT);
            j.AddField("room_index", room_index);
            j.AddField("name", player_name);
            j.AddField("answer", b.name);
            socket.Emit("answer", j);
            b.GetComponent<UnityEngine.UI.Image>().color = Color.red;
        }
        button_click = true;
    }
    void answer(SocketIOEvent e)
    {
        Query q = JsonUtility.FromJson<Query>(e.data.ToString());
        game_screen.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text += "\n"+q.query_list[0]+"-"+q.query_list[1];
    }

    void questions_ended(SocketIOEvent e)
    {
        error_display("Questions exhausted","Please quit");
    }
    #endregion

    void error_display(string title,string description)
    {
        Boolean caninvoke = true;
        try
        {
            Ad_manager.instance.bannerView.Hide();
        }
        catch
        {
            caninvoke = false;
        }
        GameObject[] e = GameObject.FindGameObjectsWithTag("error");
        if (e != null)
        {
            for (int i = 0; i < e.Length; i++)
            {
                Destroy(e[i]);
            }
        }
       
        GameObject err = Instantiate(error_prefab, main_canvas.transform);
       
        err.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text=title;
        err.transform.GetChild(2).GetComponent<TextMeshProUGUI>().text = description;
        if (caninvoke)
        {
           
            Invoke("show_bannerad", 5f);
        }
    }

    #region messaging
    public void show_messages()
    {
        TextMeshProUGUI count_obj = game_screen.transform.GetChild(4).GetChild(1).GetChild(0).gameObject.GetComponent<TextMeshProUGUI>();
        count_obj.text = "0";
        GameObject message_scroll = game_screen.transform.GetChild(5).gameObject;
        message_scroll.SetActive(!message_scroll.activeSelf);
    }
    public void send_message(TMP_InputField t)
    {
        if(t.text=="")
        {
            return;
        }
        JSONObject j = new JSONObject(JSONObject.Type.OBJECT);
        j.AddField("room_index", room_index);
        j.AddField("name", player_name);
        j.AddField("message", t.text);
        socket.Emit("message", j);
       // set_message_text(t.text, TextAlignmentOptions.Right);
        set_message_test(t.text,TextAlignmentOptions.TopRight,"You",TextAlignmentOptions.BottomRight);
        t.text = "";
    }

    void set_message_text(string msg,TextAlignmentOptions to)
    {
        GameObject message_scroll = game_screen.transform.GetChild(5).GetChild(0).GetChild(0).gameObject;
        GameObject g = Instantiate(message_object, message_scroll.transform);
        TextMeshProUGUI e = g.GetComponent<TextMeshProUGUI>();
        /*
        char[] msg_char = msg.ToCharArray();
        
        int string_lenth_limit = 20;
        for (int i = 0; i < msg_char.Length; i++)
        {
            if (i == string_lenth_limit)
            {
               
                string_lenth_limit += 20;
                g.GetComponent<RectTransform>().sizeDelta = new Vector2(g.GetComponent<RectTransform>().sizeDelta.x, g.GetComponent<RectTransform>().sizeDelta.y+27.11f);
            }
            

        }
        */
        e.text = msg;
        e.alignment = to;
    }

    void set_message_test(string msg, TextAlignmentOptions to, string name,TextAlignmentOptions no)
    {
        GameObject message_scroll = game_screen.transform.GetChild(5).GetChild(0).GetChild(0).gameObject;
       GameObject g= Instantiate(message_name, message_scroll.transform);

        g.GetComponent<TextMeshProUGUI>().alignment = no;
        g.GetComponent<TextMeshProUGUI>().text = name;
        //27.11 after 14 character
        set_message_text(msg, to);
        //set the count nd set to zero on click
      TextMeshProUGUI count_obj=game_screen.transform.GetChild(4).GetChild(1).GetChild(0).gameObject.GetComponent<TextMeshProUGUI>();
        if (!game_screen.transform.GetChild(5).gameObject.activeSelf)
        {
            count_obj.text = (int.Parse(count_obj.text) + 1).ToString();
        }
    }

    void recieve_message(SocketIOEvent e)
    {

        Query q = JsonUtility.FromJson<Query>(e.data.ToString());
        Debug.Log(q.query_list[1]);
        set_message_test(q.query_list[1] , TextAlignmentOptions.TopLeft, q.query_list[0],TextAlignmentOptions.BottomLeft);
        
    }
    #endregion

    void show_bannerad()
    {
        Ad_manager.instance.RequestBanner();
    }
}
