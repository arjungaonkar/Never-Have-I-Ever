﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
[System.Serializable]
class root
{
    public string [] questions;
}

public class demo : MonoBehaviour {
    string filepath= "C:\\Users\\Arjun\\Desktop\\raw.txt";
    string jsonpath = "C:\\Users\\Arjun\\Desktop\\questions.json";
    string[] questions;
    
	// Use this for initialization
	void Start () {
        Debug.Log(check_length("C:\\Users\\Arjun\\Desktop\\questions.json"));
        writer();
        Debug.Log(check_length("C:\\Users\\Arjun\\Desktop\\questions.json"));
    }

    int check_length(string path)
    {
        root r = JsonUtility.FromJson<root>(File.ReadAllText(path));
        return r.questions.Length;
    }
	void writer()
    {
        questions = File.ReadAllLines(filepath);
        root r = JsonUtility.FromJson<root>(File.ReadAllText(jsonpath));
        List<string> temp = new List<string>();
       // string[] temp = new string[r.questions.Length + questions.Length];
        for (int i = 0; i < r.questions.Length; i++)
        {  

            temp.Add(r.questions[i]);
        }
        for (int i = 0; i < questions.Length; i++)
        {
          
            int j;
            for ( j=0;j< r.questions.Length;j++)
            {    
                if (r.questions[j].ToLower() == questions[i].ToLower())
                {
                    Debug.Log("exsit:" + temp[j]);
                    break;
                }
               
                
            }
            if (j == r.questions.Length)
            { temp.Add(questions[i]); }

        }
        string [] t = temp.ToArray();
        r.questions = t;
        File.WriteAllText(jsonpath, JsonUtility.ToJson(r));
    }
	// Update is called once per frame
	void Update () {
		
	}
}
